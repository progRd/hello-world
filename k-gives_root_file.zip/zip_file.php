<?php
$path2mp3 = 'wp-content';
$site = 'wp-content';
$compressFolder = $site.'.zip';
$cmd = "zip -r $compressFolder $path2mp3";
                        
$compressMP3 = exec($cmd ." 2>&1" );
echo $compressMP3;
                        
if($compressMP3)
{
echo 'Done';
}
else
{
echo 'Not Done';
}