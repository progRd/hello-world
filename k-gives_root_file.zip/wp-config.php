<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp_k_gives');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'admin123');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('WP_DEBUG', false);

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '+Ew4c@Rk=$-Vp?K3O?HlY_~kqlhK8<<JluX4[;x6T(J]!}u*3|?p**pSN|.sT{YZ');
define('SECURE_AUTH_KEY', '>]E]kT[bK4L,r?-8((@.|>vO{di>ViRZ.(`pfihq.s+&~)Q:->UwwQ!mRJ@8A3!P');
define('LOGGED_IN_KEY', '51v&&P[=Ly)cCSZbpZLBa-[rO~u?T*{uq8e~|T~di*td7NW6dJNB/u<31&&IYz 7');
define('NONCE_KEY', 'RpV;-#96-`g@vw0tWAv6NDP# =Y25BY*8f_C;i}sRXTRsXDK-.s}n~[#IS<Q;OAS');
define('AUTH_SALT', 'T`;}:;d!.hvmnkrvor4M1k-V||>J+-S8GJ4RG-x{aC/n47Eje_6qF*$XT<Ob9]+d');
define('SECURE_AUTH_SALT', 'CTiSKiMz-p2~nCA:|o49yXE+z}r8u%R-PkeMqf-<D,>`^=Glz^fj?T$jj|l%DAGl');
define('LOGGED_IN_SALT', 'a*-vUWz1]QFt0F85L&n*-XHjTP.;5|NYEX@PayisnW*eJmesQ*CW+(ZRZtP0[Y:G');
define('NONCE_SALT', 'Hu%6(.7Br1b3[uh-eiLG3E?k+xAdDaNi#GBoaXi120vu--<Cv;N!1}(ABi_yTC_a');
define('FS_METHOD', direct);

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'kLkTa_';

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if (!defined('ABSPATH')) {
	define('ABSPATH', dirname(__FILE__) . '/');
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
